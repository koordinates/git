#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/mingw64/lib"
XML2_LIBS="-lxml2 -L/mingw64/lib -lz  -L/mingw64/lib -llzma    -liconv   "
XML2_INCLUDEDIR="-I/mingw64/include/libxml2"
MODULE_VERSION="xml2-2.9.12"

